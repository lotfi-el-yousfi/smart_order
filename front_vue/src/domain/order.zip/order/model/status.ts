
export enum Status {
    EN_COURS = 'en_cours',
    VALIDEE = 'validee',
    LIVREE = 'livree',
    PAYEE = 'payee'
}
